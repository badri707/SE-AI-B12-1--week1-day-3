import re
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright, expect, TimeoutError

HEADLESS = "--headless" in sys.argv
SCREENSHOT = Path(__file__).with_name("score.png")

# Selectors inspected on Cricbuzz's homepage:
# Score cards: a.h-full
# Score numbers: span.font-medium
# Ongoing match status: span.text-cbLive
CARD = 'a[href*="/live-cricket-scores/"]:has(span.font-medium)'
with sync_playwright() as p:
    browser = p.chromium.launch(headless=HEADLESS)
    page = browser.new_page(viewport={"width": 1440, "height": 900})
    page.set_default_timeout(30000)

    try:
        page.goto("https://www.cricbuzz.com/",
                  wait_until="domcontentloaded", timeout=60000)

        cards = page.locator(CARD)
        cards.first.wait_for(state="visible")
        expect(cards.first.locator("span.font-medium").first).to_have_text(
            re.compile(r"\d")
        )

        live = page.locator(
            "a.h-full:has(span.font-medium):has(span.text-cbLive)"
        ).filter(has_not_text=re.compile("stumps", re.I))

        if live.count():
            match = live.first
            print("\nLIVE CRICKET SCORE")
        else:
            match = cards.first
            print("\nNo match is currently live on the homepage.")
            print("Latest available score (may be paused or completed):")

        expect(match.locator("span.font-medium").first).to_have_text(
            re.compile(r"\d")
        )
        match.scroll_into_view_if_needed()
        print(match.inner_text())

        page.screenshot(path=str(SCREENSHOT))
        print(f"\nSaved: {SCREENSHOT}")
        print("Mode:", "headless" if HEADLESS else "headed")

        if not HEADLESS:
            input("\nCheck the browser, then press Enter here to close it.")

    except TimeoutError as error:
        print("\nActual error:", error)
        print("Page URL:", page.url)
        print("Page title:", page.title())
        page.screenshot(path="debug.png")
        Path("debug.html").write_text(page.content(), encoding="utf-8")
        input("\nBrowser kept open. Press Enter here to close it.")
    finally:
        browser.close()