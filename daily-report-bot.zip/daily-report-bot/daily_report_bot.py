import json
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path

import pyautogui
import pyperclip


pyautogui.PAUSE = 0.5
pyautogui.FAILSAFE = True


# macOS helper for creating, selecting and saving in Numbers.
# PyAutoGUI copies the website, pastes the report and screenshots it.
def numbers_command(script):
    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        text=True,
        check=True
    )
    return result.stdout.strip()


folder = Path(__file__).resolve().parent
today = datetime.now().strftime("%Y-%m-%d")

numbers_file = folder / f"daily_report_{today}.numbers"
excel_file = folder / f"daily_report_{today}.xlsx"
screenshot_file = folder / f"daily_report_{today}.png"

if numbers_file.exists() or excel_file.exists():
    raise SystemExit(
        "Today's report already exists. Rename the old report first."
    )

print("Starting bot. Do not touch the mouse or keyboard.")
time.sleep(3)

# 1. Open Chrome automatically.
subprocess.run(["open", "-a", "Google Chrome"], check=True)
time.sleep(3)

pyautogui.hotkey("command", "t")
pyautogui.write(
    "https://www.timeanddate.com/weather/india/chennai",
    interval=0.02
)
pyautogui.press("enter")

# 2. Copy the webpage and find its current temperature.
temperature = None

for attempt in range(3):
    time.sleep(8)

    # Escape leaves any address-bar selection or popup.
    pyautogui.press("esc")
    pyautogui.hotkey("command", "f")
    pyautogui.write("Feels Like")
    pyautogui.press("esc")

    pyperclip.copy("")
    pyautogui.hotkey("command", "a")
    pyautogui.hotkey("command", "c")
    time.sleep(1)

    page_text = pyperclip.paste()

    # The first temperature before "Feels Like" is the current one.
    current_section = page_text.split("Feels Like")[0]
    match = re.search(
        r"(-?\d+)\s*°\s*([CF])",
        current_section
    )

    if "Chennai" in page_text and match:
        temperature = f"{match.group(1)} °{match.group(2)}"
        break

    pyautogui.hotkey("command", "r")

if temperature is None:
    raise SystemExit(
        "Could not copy the temperature. Check the loaded webpage."
    )

# 3. Open Numbers and create a NEW blank document automatically.
numbers_command('''
tell application "Numbers"
    activate
    set reportDocument to make new document
    tell table 1 of sheet 1 of reportDocument
        set width of column 1 to 190
        set width of column 2 to 220
        set width of column 3 to 330
        set selection range to range "A1"
    end tell
end tell
''')

time.sleep(3)

# 4. Paste the headings and report into the selected cell.
report_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
weather = f"Chennai: {temperature}"
comment = "Weather checked for today's work planning."

report = (
    "Date & Time\tWeather\tComment\n"
    f"{report_time}\t{weather}\t{comment}"
)

pyperclip.copy(report)
pyautogui.hotkey("command", "v")
time.sleep(3)

# Confirm that the report actually reached Numbers.
pasted_weather = numbers_command('''
tell application "Numbers"
    tell table 1 of sheet 1 of front document
        return value of cell "B2"
    end tell
end tell
''')

if pasted_weather != weather:
    raise SystemExit(
        "The report was not pasted into Numbers. "
        "Check macOS permissions and run again."
    )

# 5. Save the Numbers document and export an Excel copy.
numbers_command(f'''
tell application "Numbers"
    save front document in POSIX file {json.dumps(str(numbers_file))}
    export front document to POSIX file {json.dumps(str(excel_file))} as Microsoft Excel
    activate
end tell
''')

time.sleep(2)

# 6. Screenshot the final Numbers sheet.
pyautogui.screenshot().save(str(screenshot_file))

print("Report completed!")
print(f"Numbers: {numbers_file.name}")
print(f"Excel: {excel_file.name}")
print(f"Screenshot: {screenshot_file.name}")