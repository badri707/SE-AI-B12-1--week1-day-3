# PyAutoGUI Daily Report Bot

Gen AI Architect Program — Assignment 1

A macOS bot that opens Chrome, copies Chennai's current temperature, and prepares a daily report in Apple Numbers.

## Features
- Automatically generates the date and time.
- Adds the weather and a short comment.
- Saves dated Numbers and Excel files.
- Takes a screenshot of the completed sheet.

## Tools
Python, PyAutoGUI, Pyperclip, Pillow, and AppleScript.

PyAutoGUI handles browser interaction, pasting, and screenshots. AppleScript handles Numbers document creation, saving, and Excel export.

## Setup
Requires macOS, Google Chrome, Apple Numbers, and Python 3.

Install the libraries:
    pip install -r requirements.txt

Run the bot:
    python daily_report_bot.py

Allow Accessibility, Screen Recording, and control of Numbers when prompted. Do not touch the mouse or keyboard while the bot runs.

Outputs are saved beside the Python script. Rename existing reports before running again on the same day.

## Sample Report
[Download Excel report](output/daily_report_2026-10-01.xlsx)

## Screenshot
![Completed report](screenshots/daily_report_2026-10-01.png)
